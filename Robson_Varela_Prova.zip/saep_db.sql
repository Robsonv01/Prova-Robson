﻿-- SAEP: criação e população. Preserve a chave AES usada nesta carga.
USE [master];
GO
IF DB_ID(N'ClinicaVetDb') IS NULL CREATE DATABASE [ClinicaVetDb];
GO
USE [ClinicaVetDb];
GO
IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO


SET XACT_ABORT ON;
BEGIN TRANSACTION;
SET IDENTITY_INSERT [Usuarios] ON;
IF NOT EXISTS (SELECT 1 FROM [Usuarios] WHERE [Id] = 1) INSERT INTO [Usuarios] ([Id],[Nome],[Email],[SenhaHash],[Perfil]) VALUES (1,N'Administrador',N'admin@clinica.com',N'$2a$11$SpLFJWmBw7f4Wg4SC5AqIuqafhTm8mE2fTLtt5qk/6oYVIAd1tn0e',N'Administrador');
IF NOT EXISTS (SELECT 1 FROM [Usuarios] WHERE [Id] = 2) INSERT INTO [Usuarios] ([Id],[Nome],[Email],[SenhaHash],[Perfil]) VALUES (2,N'Ana Recepção',N'ana@clinica.com',N'$2a$11$NUXYj3ndt5qTyROnikMoYeDp9tTtv9qZXS.0vp/4COEputEhn33Pq',N'Usuario');
IF NOT EXISTS (SELECT 1 FROM [Usuarios] WHERE [Id] = 3) INSERT INTO [Usuarios] ([Id],[Nome],[Email],[SenhaHash],[Perfil]) VALUES (3,N'Carlos Recepção',N'carlos@clinica.com',N'$2a$11$Q41enc/XMPUtGZp9yHInYuQilQpEle94TPniiLWNAg99BmEdcQBdu',N'Usuario');
SET IDENTITY_INSERT [Usuarios] OFF;
SET IDENTITY_INSERT [Tutores] ON;
IF NOT EXISTS (SELECT 1 FROM [Tutores] WHERE [Id] = 1) INSERT INTO [Tutores] ([Id],[Nome],[CpfCriptografado],[Telefone],[Email]) VALUES (1,N'João Silva',N't+9ewA07qZUv5YvYr+Yp/hZkrhbHxq/zI9VW2iS5XVExICzwxEU7',N'54999990001',N'joao@email.com');
IF NOT EXISTS (SELECT 1 FROM [Tutores] WHERE [Id] = 2) INSERT INTO [Tutores] ([Id],[Nome],[CpfCriptografado],[Telefone],[Email]) VALUES (2,N'Maria Souza',N'ZZMWgO3hp+udSkEJdHt2LjZVIYhYPZS3hTFosEMcolAjFT2LR5e5',N'54999990002',N'maria@email.com');
IF NOT EXISTS (SELECT 1 FROM [Tutores] WHERE [Id] = 3) INSERT INTO [Tutores] ([Id],[Nome],[CpfCriptografado],[Telefone],[Email]) VALUES (3,N'Pedro Lima',N'QocAVXHNA5zyjzGHGBlyXg/H6PQ/h7hjaF8vO50MnWLhbyLVyEvN',N'54999990003',N'pedro@email.com');
SET IDENTITY_INSERT [Tutores] OFF;
SET IDENTITY_INSERT [Pets] ON;
IF NOT EXISTS (SELECT 1 FROM [Pets] WHERE [Id] = 1) INSERT INTO [Pets] ([Id],[Nome],[Especie],[Raca],[DataNascimento],[TutorId]) VALUES (1,N'Rex',N'Cachorro',N'Labrador',NULL,1);
IF NOT EXISTS (SELECT 1 FROM [Pets] WHERE [Id] = 2) INSERT INTO [Pets] ([Id],[Nome],[Especie],[Raca],[DataNascimento],[TutorId]) VALUES (2,N'Mia',N'Gato',N'Siamês',NULL,2);
IF NOT EXISTS (SELECT 1 FROM [Pets] WHERE [Id] = 3) INSERT INTO [Pets] ([Id],[Nome],[Especie],[Raca],[DataNascimento],[TutorId]) VALUES (3,N'Thor',N'Cachorro',N'SRD',NULL,3);
SET IDENTITY_INSERT [Pets] OFF;
SET IDENTITY_INSERT [Agendamentos] ON;
IF NOT EXISTS (SELECT 1 FROM [Agendamentos] WHERE [Id] = 1) INSERT INTO [Agendamentos] ([Id],[DataHora],[Motivo],[Status],[TutorId],[PetId]) VALUES (1,'2026-11-13T09:00:00.0000000',N'Vacinação',N'Agendado',1,1);
IF NOT EXISTS (SELECT 1 FROM [Agendamentos] WHERE [Id] = 2) INSERT INTO [Agendamentos] ([Id],[DataHora],[Motivo],[Status],[TutorId],[PetId]) VALUES (2,'2026-11-14T14:00:00.0000000',N'Consulta',N'Agendado',2,2);
IF NOT EXISTS (SELECT 1 FROM [Agendamentos] WHERE [Id] = 3) INSERT INTO [Agendamentos] ([Id],[DataHora],[Motivo],[Status],[TutorId],[PetId]) VALUES (3,'2026-11-15T10:00:00.0000000',N'Retorno',N'Agendado',3,3);
SET IDENTITY_INSERT [Agendamentos] OFF;
COMMIT;
GO
SELECT 'Usuarios' AS Tabela, COUNT(*) AS Quantidade FROM Usuarios UNION ALL SELECT 'Tutores', COUNT(*) FROM Tutores UNION ALL SELECT 'Pets', COUNT(*) FROM Pets UNION ALL SELECT 'Agendamentos', COUNT(*) FROM Agendamentos;
GO
