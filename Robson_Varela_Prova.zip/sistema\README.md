# Clínica Veterinária

Sistema web desenvolvido com **ASP.NET Core MVC (.NET 8)**, SQL Server, autenticação JWT, senhas protegidas com BCrypt e criptografia AES-GCM para os CPFs.

## Como executar

1. Abra o PowerShell ou o terminal do Visual Studio Code.
2. Entre na pasta `sistema`:

   ```powershell
   cd .\sistema
   ```

   Se o terminal estiver na pasta que contém `Prova.sln`, o caminho será:

   ```powershell
   cd .\Prova\sistema
   ```

3. Execute:

   ```powershell
   dotnet run
   ```

4. Aguarde o endereço HTTPS aparecer no terminal e abra esse endereço no navegador.
5. Na tela de login, informe um dos usuários de teste abaixo.

## Usuários de acesso

| Perfil | E-mail (login) | Senha |
|---|---|---|
| Administrador | `admin@clinica.com` | `Admin@123` |
| Recepção | `ana@clinica.com` | `Ana@123` |
| Recepção | `carlos@clinica.com` | `Carlos@123` |

As contas são criadas automaticamente pelo inicializador quando a tabela `Usuarios` está vazia. As senhas são armazenadas como hashes BCrypt, não em texto puro.

## Requisitos para executar

- SDK do **.NET 8** instalado.
- SQL Server Express em execução, com a instância `localhost\\SQLEXPRESS` (ou conexão ajustada em `appsettings.json`).
- Banco `ClinicaVetDb` preparado com as migrations/tabelas do projeto.
- Configurações `Jwt:Key` e `Encryption:Key` disponíveis no ambiente Development por User Secrets ou variáveis de ambiente.
- Certificado HTTPS de desenvolvimento confiável no Windows.

> **Atenção ao copiar para outro computador:** o arquivo ZIP não transporta os User Secrets do computador de desenvolvimento. O projeto precisa receber as chaves `Jwt:Key` e `Encryption:Key` no novo ambiente. A chave AES deve ser a mesma usada para cifrar os CPFs que já estão no banco/arquivo SQL; gerar outra chave impede a descriptografia desses dados. Não publique nem compartilhe essas chaves.

## Se for a primeira execução neste computador

Na pasta `sistema`, confira se o SQL Server está iniciado e se as configurações e o banco já foram preparados. Caso as chaves ainda não estejam configuradas, siga a etapa 05 do roteiro indicado abaixo. Caso o banco ainda não tenha sido criado, aplique as migrations do projeto antes de iniciar a aplicação.

Para confiar no certificado HTTPS de desenvolvimento, execute uma vez:

```powershell
dotnet dev-certs https --trust
```

## Encerrar a aplicação

No terminal em que `dotnet run` está em execução, pressione `Ctrl + C`.

## Roteiro de referência

Este projeto segue o roteiro **Clínica Veterinária — .NET 8 MVC + JWT**, incluindo as etapas de configuração do ambiente, banco de dados, autenticação, tutores, pets, agendamentos e geração do SQL:

https://devflexa.github.io/rotina/#step-23

Consulte especialmente:
- **Etapa 05:** configuração do banco, JWT e chave AES.
- **Etapas 21 e 22:** criação do banco e primeira execução em HTTPS.
- **Etapa 23:** geração e conferência do arquivo `saep_db.sql`.
- **Etapa 25:** testes e organização da entrega.

---
